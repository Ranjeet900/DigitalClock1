# Digital clock!

A Pen created on CodePen.io. Original URL: [https://codepen.io/deep-io/pen/MWXNgQX](https://codepen.io/deep-io/pen/MWXNgQX).

